package com.test.csvToXml;

import generated.Configs;
import generated.EParamType;
import generated.TConfig;
import generated.TParam;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import lombok.SneakyThrows;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Arrays;
import java.util.List;

public class Main {

    @SneakyThrows
    public static void main(String[] args) {
        List<String> ficheiro = Arrays.asList(
                "trigram,typeofdata,dateofext,order,boc,intern_order,indicator,status",
                "trigram2,typeofdata2,dateofext2,order2,boc2,intern_order2,indicator2,status2"
        );
        Configs configs = loadConfigs("Z:\\projects\\Java\\CsvToXML\\src\\main\\resources\\config.xml");
        // .. encontrar a config certa
        TConfig config = configs.getConfig().get(0);
        Parser parser = new Parser(config, ficheiro);
        parser.parse("./ouput.xml");


    }

    private static Configs loadConfigs(String s) throws JAXBException, FileNotFoundException {
        JAXBContext context = JAXBContext.newInstance(Configs.class);
        return (Configs) context.createUnmarshaller()
                .unmarshal(new FileReader(s));
    }

}
