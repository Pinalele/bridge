package com.test.csvToXml;

import generated.EParamType;
import generated.TComplexType;
import generated.TConfig;
import generated.TParam;
import lombok.Data;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.List;

@Data
public class Parser {
    private final TConfig config;
    private final List<String> ficheiro;

    DocumentBuilderFactory documentFactory;
    DocumentBuilder documentBuilder;
    Document document;

    @SneakyThrows
    public Parser(TConfig config, List<String> ficheiro) {
        this.config = config;
        this.ficheiro = ficheiro;
        documentFactory = DocumentBuilderFactory.newInstance();
        documentBuilder = documentFactory.newDocumentBuilder();
        document = documentBuilder.newDocument();
    }

    @SneakyThrows
    public void parse(String output) throws ParserConfigurationException {
        // root element
        Element root = document.createElement("root");
        document.appendChild(root);

        for (String line : ficheiro) {
            Element lineElem = document.createElement("elem");
            root.appendChild(lineElem);

            String[] cells = line.split(",");
            for (TParam param : config.getParams().getParam()) {
                handleParam(cells, param, lineElem);

            }
        }
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource domSource = new DOMSource(document);
        StreamResult streamResult = new StreamResult(new File(output));

        // If you use
        // StreamResult result = new StreamResult(System.out);
        // the output will be pushed to the standard output ...
        // You can use that for debugging

        transformer.transform(domSource, streamResult);
    }

    private void handleParam(String[] cells, TParam param, Element parent) {
        Element element = document.createElement(param.getTag());
        parent.appendChild(element);
        if (param.getType() == EParamType.COMPLEX) {
            TComplexType complexType = param.getComplex();
            for (TParam p : complexType.getParam()) {
                handleParam(cells, p, element);
            }
            return;
        }
        element.appendChild(document.createTextNode(cells[Math.toIntExact(param.getIndex())]));
    }


}
